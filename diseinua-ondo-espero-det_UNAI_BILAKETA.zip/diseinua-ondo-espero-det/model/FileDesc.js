const { Schema, model } = require('mongoose');

const prodSchema = new Schema({
    idFile: { type: String, trim: true, default: "", required: true, unique: true }, // filename
    owner: { type: String, trim: true, default: "", require: true }, // is a token
    name: { type: String, trim: true, default: "", require: true }, // name file + estension
    parent: { type: String, trim: true, default: "", require: true }, // idFolder which is inside
    linkView: { type: String, trim: true, default: "" }, // _id + random_string
    visibleToEveryone: { type: Boolean, default: true },
    type: { type: String, trim: true, default: "" },
    createdAt: { type: Date, default: Date.now },
    sizeFile: { type: Number, default: 0 }, // size in kb
    likes: { type: Number, default: 0},
    komunitatea: {type: String, required: false, default: ""},
    isImage:{type:Boolean,required:true,default:false},
    //img: {type: Boolean},
})

module.exports = prodSchema;