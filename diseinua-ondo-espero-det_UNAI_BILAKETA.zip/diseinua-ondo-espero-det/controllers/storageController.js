var storageModel =require('../model/storageModel');
var check = require('./isLoggedIn');


exports.index=function (req, res){
    check.isLoggedIn(req,res);
   storageModel.index(req,res);
    //res.render('pages/storage', { erabiltzailea: 'iker', files: files });
}

exports.fitxategiaIgo=(req, res)=>{
    check.isLoggedIn(req,res);
    storageModel.fitxategiaIgo(req,res);
}
exports.fitxategiakLortu=(req,res)=>{
    check.isLoggedIn(req,res);
    storageModel.fitxategiakLortu(req,res);
    res.render('pages/storage', {files:files} );
}
exports.fitxategiaBistaratu=(req,res)=>{
    check.isLoggedIn(req,res);
    storageModel.fitxategiaBistaratu(req,res);
}
exports.deleteFile=(req,res)=>{
    check.isLoggedIn(req,res);
    storageModel.deleteFile(req,res);
    res.redirect('/storage');
}
exports.irudiakJSON=(req,res)=>{
    check.isLoggedIn(req,res);
    storageModel.irudiakJSON(req,res);
}

exports.bezeroarenFitxategiak=(req,res)=>{
    check.isLoggedIn(req,res);
    console.log('Username:***'+req.user.username);
    storageModel.bezeroarenFitxategiak(req,res);
}

exports.publikoaEgin = (req, res) => {
    check.isLoggedIn(req,res);
    storageModel.publikoEgin(req,res);
}
